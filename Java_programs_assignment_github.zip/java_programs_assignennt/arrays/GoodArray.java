import java.util.Scanner;

public class GoodArray {
    static int findGcd(int firstNumber, int secondNumber) {
        while (secondNumber != 0) {
            int remainder = firstNumber % secondNumber;
            firstNumber = secondNumber;
            secondNumber = remainder;
        }

        return firstNumber;
    }

    static boolean isGoodArray(int[] numbers) {
        int commonGcd = 0;

        for (int number : numbers) {
            commonGcd = findGcd(commonGcd, Math.abs(number));

            if (commonGcd == 1) {
                return true;
            }
        }

        return commonGcd == 1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter array size: ");
        int size = scanner.nextInt();

        int[] numbers = new int[size];

        System.out.println("Enter array elements:");
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }

        System.out.println(isGoodArray(numbers));
    }
}
