import java.util.Arrays;
import java.util.Scanner;

public class FirstMissingPositive {
    static int findFirstMissingPositive(int[] numbers) {
        int size = numbers.length;

        for (int i = 0; i < size; i++) {
            while (numbers[i] > 0 &&
                   numbers[i] <= size &&
                   numbers[numbers[i] - 1] != numbers[i]) {

                int temp = numbers[i];
                numbers[i] = numbers[temp - 1];
                numbers[temp - 1] = temp;
            }
        }

        for (int i = 0; i < size; i++) {
            if (numbers[i] != i + 1) {
                return i + 1;
            }
        }

        return size + 1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter array size: ");
        int size = scanner.nextInt();

        int[] numbers = new int[size];

        System.out.println("Enter array elements:");
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }

        int missingNumber = findFirstMissingPositive(numbers);

        System.out.println("First missing positive = " + missingNumber);
    }
}
