import java.util.Arrays;
import java.util.Scanner;

public class ProductOfArrayExceptSelf {
    static int[] productExceptSelf(int[] numbers) {
        int size = numbers.length;
        int[] products = new int[size];

        int leftProduct = 1;

        for (int i = 0; i < size; i++) {
            products[i] = leftProduct;
            leftProduct *= numbers[i];
        }

        int rightProduct = 1;

        for (int i = size - 1; i >= 0; i--) {
            products[i] *= rightProduct;
            rightProduct *= numbers[i];
        }

        return products;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter array size: ");
        int size = scanner.nextInt();

        int[] numbers = new int[size];

        System.out.println("Enter array elements:");
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }

        int[] result = productExceptSelf(numbers);

        System.out.println(Arrays.toString(result));
    }
}
