import java.util.Arrays;
import java.util.Scanner;

public class RotateArray {
    static void reverse(int[] numbers, int start, int end) {
        while (start < end) {
            int temp = numbers[start];
            numbers[start] = numbers[end];
            numbers[end] = temp;
            start++;
            end--;
        }
    }

    static void rotate(int[] numbers, int steps) {
        int size = numbers.length;

        if (size == 0) {
            return;
        }

        steps %= size;

        reverse(numbers, 0, size - 1);
        reverse(numbers, 0, steps - 1);
        reverse(numbers, steps, size - 1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter array size: ");
        int size = scanner.nextInt();

        int[] numbers = new int[size];

        System.out.println("Enter array elements:");
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }

        System.out.print("Enter number of rotations: ");
        int steps = scanner.nextInt();

        rotate(numbers, steps);

        System.out.println(Arrays.toString(numbers));
    }
}
