import java.util.Arrays;
import java.util.Scanner;

public class FindFirstAndLastPosition {
    static int findFirst(int[] numbers, int target) {
        int left = 0;
        int right = numbers.length - 1;
        int answer = -1;

        while (left <= right) {
            int middle = left + (right - left) / 2;

            if (numbers[middle] == target) {
                answer = middle;
                right = middle - 1;
            } else if (numbers[middle] < target) {
                left = middle + 1;
            } else {
                right = middle - 1;
            }
        }

        return answer;
    }

    static int findLast(int[] numbers, int target) {
        int left = 0;
        int right = numbers.length - 1;
        int answer = -1;

        while (left <= right) {
            int middle = left + (right - left) / 2;

            if (numbers[middle] == target) {
                answer = middle;
                left = middle + 1;
            } else if (numbers[middle] < target) {
                left = middle + 1;
            } else {
                right = middle - 1;
            }
        }

        return answer;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter array size: ");
        int size = scanner.nextInt();

        int[] numbers = new int[size];

        System.out.println("Enter sorted array elements:");
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }

        System.out.print("Enter target: ");
        int target = scanner.nextInt();

        int firstPosition = findFirst(numbers, target);
        int lastPosition = findLast(numbers, target);

        System.out.println(Arrays.toString(new int[]{firstPosition, lastPosition}));
    }
}
