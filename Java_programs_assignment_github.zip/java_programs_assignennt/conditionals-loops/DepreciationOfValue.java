import java.util.Scanner;

public class DepreciationOfValue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter original value: ");
        double originalValue = scanner.nextDouble();

        System.out.print("Enter depreciation rate (%): ");
        double depreciationRate = scanner.nextDouble();

        System.out.print("Enter number of years: ");
        int years = scanner.nextInt();

        double currentValue = originalValue;

        for (int i = 1; i <= years; i++) {
            currentValue -= currentValue * depreciationRate / 100;
        }

        System.out.println("Value after depreciation = " + currentValue);
    }
}
