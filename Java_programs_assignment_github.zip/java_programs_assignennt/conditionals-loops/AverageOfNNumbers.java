import java.util.Scanner;

public class AverageOfNNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter how many numbers: ");
        int count = scanner.nextInt();

        double total = 0;

        for (int i = 1; i <= count; i++) {
            System.out.print("Enter number " + i + ": ");
            double number = scanner.nextDouble();
            total += number;
        }

        double average = total / count;

        System.out.println("Average = " + average);
    }
}
