import java.util.Scanner;

public class CommissionPercentage {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter sales amount: ");
        double salesAmount = scanner.nextDouble();

        System.out.print("Enter commission amount: ");
        double commissionAmount = scanner.nextDouble();

        double commissionPercent = (commissionAmount / salesAmount) * 100;

        System.out.println("Commission Percentage = " + commissionPercent + "%");
    }
}
