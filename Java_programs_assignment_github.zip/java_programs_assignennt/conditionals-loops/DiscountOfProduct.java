import java.util.Scanner;

public class DiscountOfProduct {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();

        System.out.print("Enter discount percentage: ");
        double discountPercent = scanner.nextDouble();

        double discount = price * discountPercent / 100;
        double finalPrice = price - discount;

        System.out.println("Discount = " + discount);
        System.out.println("Final Price = " + finalPrice);
    }
}
