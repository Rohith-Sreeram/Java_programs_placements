import java.util.Scanner;

public class MaximumMinimum {
    static void printMaximum(int firstNumber, int secondNumber, int thirdNumber) {
        int maximum = Math.max(firstNumber, Math.max(secondNumber, thirdNumber));
        System.out.println("Maximum = " + maximum);
    }

    static void printMinimum(int firstNumber, int secondNumber, int thirdNumber) {
        int minimum = Math.min(firstNumber, Math.min(secondNumber, thirdNumber));
        System.out.println("Minimum = " + minimum);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first number: ");
        int firstNumber = scanner.nextInt();

        System.out.print("Enter second number: ");
        int secondNumber = scanner.nextInt();

        System.out.print("Enter third number: ");
        int thirdNumber = scanner.nextInt();

        printMaximum(firstNumber, secondNumber, thirdNumber);
        printMinimum(firstNumber, secondNumber, thirdNumber);
    }
}
