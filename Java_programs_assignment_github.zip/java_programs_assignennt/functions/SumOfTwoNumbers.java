import java.util.Scanner;

public class SumOfTwoNumbers {
    static int addNumbers(int firstNumber, int secondNumber) {
        return firstNumber + secondNumber;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first number: ");
        int firstNumber = scanner.nextInt();

        System.out.print("Enter second number: ");
        int secondNumber = scanner.nextInt();

        int sum = addNumbers(firstNumber, secondNumber);

        System.out.println("Sum = " + sum);
    }
}
