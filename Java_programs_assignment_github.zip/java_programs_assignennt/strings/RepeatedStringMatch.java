import java.util.Scanner;

public class RepeatedStringMatch {
    static int repeatedStringMatch(String firstText, String secondText) {
        StringBuilder repeatedText = new StringBuilder();
        int count = 0;

        while (repeatedText.length() < secondText.length()) {
            repeatedText.append(firstText);
            count++;
        }

        if (repeatedText.indexOf(secondText) != -1) {
            return count;
        }

        repeatedText.append(firstText);

        if (repeatedText.indexOf(secondText) != -1) {
            return count + 1;
        }

        return -1;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first string: ");
        String firstText = scanner.nextLine();

        System.out.print("Enter second string: ");
        String secondText = scanner.nextLine();

        System.out.println(repeatedStringMatch(firstText, secondText));
    }
}
