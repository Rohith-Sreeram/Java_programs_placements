import java.util.Scanner;
import java.util.Stack;

public class BasicCalculator {
    static int calculate(String expression) {
        Stack<Integer> values = new Stack<>();

        int result = 0;
        int number = 0;
        int sign = 1;

        for (int i = 0; i < expression.length(); i++) {
            char current = expression.charAt(i);

            if (Character.isDigit(current)) {
                number = number * 10 + (current - '0');
            } else if (current == '+') {
                result += sign * number;
                number = 0;
                sign = 1;
            } else if (current == '-') {
                result += sign * number;
                number = 0;
                sign = -1;
            } else if (current == '(') {
                values.push(result);
                values.push(sign);

                result = 0;
                number = 0;
                sign = 1;
            } else if (current == ')') {
                result += sign * number;
                number = 0;

                int previousSign = values.pop();
                int previousResult = values.pop();

                result = previousResult + previousSign * result;
                sign = 1;
            }
        }

        result += sign * number;

        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter expression: ");
        String expression = scanner.nextLine();

        System.out.println("Result = " + calculate(expression));
    }
}
