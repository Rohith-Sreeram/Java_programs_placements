import java.util.Scanner;

public class MultiplyStrings {
    static String multiply(String firstNumber, String secondNumber) {
        if (firstNumber.equals("0") || secondNumber.equals("0")) {
            return "0";
        }

        int[] result = new int[firstNumber.length() + secondNumber.length()];

        for (int i = firstNumber.length() - 1; i >= 0; i--) {
            for (int j = secondNumber.length() - 1; j >= 0; j--) {
                int firstDigit = firstNumber.charAt(i) - '0';
                int secondDigit = secondNumber.charAt(j) - '0';

                int position = i + j + 1;
                int product = firstDigit * secondDigit + result[position];

                result[position] = product % 10;
                result[position - 1] += product / 10;
            }
        }

        StringBuilder answer = new StringBuilder();

        for (int digit : result) {
            if (answer.length() == 0 && digit == 0) {
                continue;
            }

            answer.append(digit);
        }

        return answer.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first number: ");
        String firstNumber = scanner.nextLine();

        System.out.print("Enter second number: ");
        String secondNumber = scanner.nextLine();

        System.out.println("Product = " + multiply(firstNumber, secondNumber));
    }
}
