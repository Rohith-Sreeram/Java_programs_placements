import java.util.Scanner;

public class SplitTwoStringsToMakePalindrome {
    static boolean isPalindrome(String text, int left, int right) {
        while (left < right) {
            if (text.charAt(left) != text.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }

        return true;
    }

    static boolean checkSplit(String firstText, String secondText) {
        int left = 0;
        int right = firstText.length() - 1;

        while (left < right && firstText.charAt(left) == secondText.charAt(right)) {
            left++;
            right--;
        }

        return isPalindrome(firstText, left, right) ||
               isPalindrome(secondText, left, right);
    }

    static boolean checkPalindromeFormation(String firstText, String secondText) {
        return checkSplit(firstText, secondText) ||
               checkSplit(secondText, firstText);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first string: ");
        String firstText = scanner.nextLine();

        System.out.print("Enter second string: ");
        String secondText = scanner.nextLine();

        System.out.println(checkPalindromeFormation(firstText, secondText));
    }
}
