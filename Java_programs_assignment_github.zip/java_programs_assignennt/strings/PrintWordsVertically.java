import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PrintWordsVertically {
    static List<String> printVertically(String sentence) {
        String[] words = sentence.split(" ");
        int longestWord = 0;

        for (String word : words) {
            longestWord = Math.max(longestWord, word.length());
        }

        List<String> result = new ArrayList<>();

        for (int column = 0; column < longestWord; column++) {
            StringBuilder line = new StringBuilder();

            for (String word : words) {
                if (column < word.length()) {
                    line.append(word.charAt(column));
                } else {
                    line.append(' ');
                }
            }

            result.add(removeTrailingSpaces(line.toString()));
        }

        return result;
    }

    static String removeTrailingSpaces(String text) {
        int lastCharacter = text.length() - 1;

        while (lastCharacter >= 0 && text.charAt(lastCharacter) == ' ') {
            lastCharacter--;
        }

        return text.substring(0, lastCharacter + 1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a sentence: ");
        String sentence = scanner.nextLine();

        List<String> result = printVertically(sentence);

        for (String line : result) {
            System.out.println(line);
        }
    }
}
