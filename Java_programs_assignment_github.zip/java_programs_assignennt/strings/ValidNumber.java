import java.util.Scanner;

public class ValidNumber {
    static boolean isNumber(String text) {
        text = text.trim();

        if (text.isEmpty()) {
            return false;
        }

        boolean hasDigit = false;
        boolean hasDot = false;
        boolean hasExponent = false;
        boolean exponentDigit = true;

        for (int i = 0; i < text.length(); i++) {
            char current = text.charAt(i);

            if (Character.isDigit(current)) {
                hasDigit = true;

                if (hasExponent) {
                    exponentDigit = true;
                }
            } else if (current == '+' || current == '-') {
                if (i != 0 && text.charAt(i - 1) != 'e' && text.charAt(i - 1) != 'E') {
                    return false;
                }
            } else if (current == '.') {
                if (hasDot || hasExponent) {
                    return false;
                }

                hasDot = true;
            } else if (current == 'e' || current == 'E') {
                if (hasExponent || !hasDigit) {
                    return false;
                }

                hasExponent = true;
                exponentDigit = false;
            } else {
                return false;
            }
        }

        return hasDigit && exponentDigit;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a value: ");
        String text = scanner.nextLine();

        System.out.println(isNumber(text));
    }
}
